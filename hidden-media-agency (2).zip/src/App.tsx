/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { Layout } from './components/Layout';
import { AdminProvider } from './context/AdminContext';
import { useEffect, useState } from 'react';
import { initDB } from './lib/db';
import { Splash } from './components/Splash';
import { AnimatePresence, motion } from 'motion/react';

import Home from './pages/Home';
import Portfolio from './pages/Portfolio';
import Pricing from './pages/Pricing';
import About from './pages/About';
import Contact from './pages/Contact';
import Login from './pages/Login';

export default function App() {
  const [dbReady, setDbReady] = useState(false);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    initDB().then(() => setDbReady(true));
  }, []);

  if (!dbReady) return null;

  return (
    <HelmetProvider>
      <AdminProvider>
        <AnimatePresence mode="wait">
          {showSplash ? (
            <Splash key="splash" onComplete={() => setShowSplash(false)} />
          ) : (
            <motion.div
              key="app"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <BrowserRouter>
                <Routes>
                  <Route path="/" element={<Layout />}>
                    <Route index element={<Home />} />
                    <Route path="portfolio" element={<Portfolio />} />
                    <Route path="pricing" element={<Pricing />} />
                    <Route path="about" element={<About />} />
                    <Route path="contact" element={<Contact />} />
                    <Route path="login" element={<Login />} />
                  </Route>
                </Routes>
              </BrowserRouter>
            </motion.div>
          )}
        </AnimatePresence>
      </AdminProvider>
    </HelmetProvider>
  );
}
