import { MessageCircle } from 'lucide-react';
import { getWhatsAppLink } from '../lib/whatsapp';
import { WhatsAppButton } from './WhatsAppButton';

export function FloatingWhatsApp() {
  return (
    <div className="fixed bottom-6 right-6 z-50">
      <WhatsAppButton
        url={getWhatsAppLink()}
        className="bg-[#25D366] text-brand-blue p-4 rounded-full border-4 border-brand-yellow shadow-[4px_4px_0px_0px_#003366] hover:-translate-y-2 hover:shadow-[6px_6px_0px_0px_#003366] transition-all flex items-center justify-center animate-btn-pulse"
      >
        <MessageCircle className="w-8 h-8 text-white" />
      </WhatsAppButton>
    </div>
  );
}
