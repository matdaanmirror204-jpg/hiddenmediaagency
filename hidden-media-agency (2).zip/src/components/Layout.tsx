import { Link, Outlet, useLocation } from 'react-router-dom';
import { useAdmin } from '../context/AdminContext';
import { Menu, X, LogOut, ShieldAlert } from 'lucide-react';
import { useState } from 'react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { WHATSAPP_NUMBER } from '../lib/whatsapp';
import { FloatingWhatsApp } from './FloatingWhatsApp';

const navItems = [
  { name: 'Overview', path: '/' },
  { name: 'Portfolio', path: '/portfolio' },
  { name: 'Pricing', path: '/pricing' },
  { name: 'About', path: '/about' },
  { name: 'Contact', path: '/contact' },
];

export function Layout() {
  const { isAdmin, logout } = useAdmin();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  return (
    <div className="min-h-screen flex flex-col font-sans">
      <header className="sticky top-0 z-50 bg-brand-blue border-b-4 border-brand-saffron shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-12 h-12 bg-brand-yellow rounded-xl border-2 border-brand-saffron flex items-center justify-center shadow-[4px_4px_0px_0px_#FF9933] group-hover:-translate-y-1 group-hover:shadow-[6px_6px_0px_0px_#FF9933] transition-all relative overflow-hidden">
                {/* Decorative shapes */}
                <div className="absolute -top-3 -right-3 w-8 h-8 bg-brand-saffron rounded-full opacity-50"></div>
                <div className="absolute -bottom-3 -left-3 w-8 h-8 bg-brand-blue rounded-full opacity-30"></div>
                {/* Text Logo */}
                <span className="font-black text-2xl text-brand-blue z-10 tracking-tighter">HM</span>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-brand-yellow drop-shadow-[2px_2px_0px_#FF9933] tracking-wider uppercase leading-none">
                  Hidden Media
                </span>
                <span className="text-sm font-medium text-white tracking-widest uppercase opacity-90 mt-1 leading-none">
                  Agency
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-1 items-center">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "px-4 py-2 rounded-lg font-bold text-sm uppercase tracking-wide transition-all duration-200",
                    location.pathname === item.path
                      ? "bg-brand-saffron text-brand-blue shadow-[3px_3px_0px_0px_#FFFF00] -translate-y-1"
                      : "text-white hover:bg-white/10 hover:-translate-y-0.5"
                  )}
                >
                  {item.name}
                </Link>
              ))}
              
              {isAdmin ? (
                <button
                  onClick={logout}
                  className="ml-4 px-4 py-2 flex items-center gap-2 bg-red-600 text-white font-bold rounded-lg shadow-[3px_3px_0px_0px_#7f1d1d] hover:-translate-y-0.5 transition-all text-sm"
                >
                  <LogOut className="w-4 h-4" /> Admin Logout
                </button>
              ) : (
                <Link
                  to="/login"
                  className={cn(
                    "ml-4 px-4 py-2 rounded-lg font-bold text-sm uppercase tracking-wide transition-all duration-200 border-2 border-transparent",
                    location.pathname === '/login'
                      ? "bg-brand-yellow text-brand-blue shadow-[3px_3px_0px_0px_#FF9933] -translate-y-1"
                      : "text-brand-yellow hover:border-brand-yellow hover:-translate-y-0.5"
                  )}
                >
                  Admin Login
                </Link>
              )}
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 text-brand-saffron"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden bg-brand-blue border-b-4 border-brand-saffron overflow-hidden"
            >
              <div className="px-4 pt-2 pb-6 space-y-2 flex flex-col">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={cn(
                      "px-4 py-3 rounded-lg font-bold text-base uppercase tracking-wide block transition-all",
                      location.pathname === item.path
                        ? "bg-brand-saffron text-brand-blue shadow-[3px_3px_0px_0px_#FFFF00]"
                        : "text-white active:bg-white/10"
                    )}
                  >
                    {item.name}
                  </Link>
                ))}
                {isAdmin ? (
                  <button
                    onClick={() => {
                      logout();
                      setMobileMenuOpen(false);
                    }}
                    className="px-4 py-3 mt-4 text-left flex items-center gap-2 bg-red-600 text-white font-bold rounded-lg shadow-[3px_3px_0px_0px_#7f1d1d]"
                  >
                    <LogOut className="w-5 h-5" /> Admin Logout
                  </button>
                ) : (
                  <Link
                    to="/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="px-4 py-3 mt-4 text-center font-bold text-brand-blue bg-brand-yellow rounded-lg shadow-[3px_3px_0px_0px_#FF9933] uppercase"
                  >
                    Admin Login
                  </Link>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {isAdmin && (
        <div className="bg-red-500 text-white text-center py-1 font-bold text-sm flex items-center justify-center gap-2 shadow-[0px_4px_0px_0px_#7f1d1d]">
          <ShieldAlert className="w-4 h-4" /> You are logged in as Admin. You have full edit access.
        </div>
      )}

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        <Outlet />
      </main>

      <FloatingWhatsApp />
      
      <footer className="bg-brand-blue border-t-8 border-brand-saffron pt-12 pb-8 mt-12 text-white/90">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {/* Branding & About */}
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-brand-yellow rounded-lg flex items-center justify-center">
                  <span className="font-black text-xl text-brand-blue">HM</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-xl font-bold text-brand-yellow leading-none tracking-wider uppercase">Hidden Media</span>
                  <span className="text-xs font-medium text-white tracking-widest uppercase opacity-90 mt-1">Agency</span>
                </div>
              </div>
              <p className="text-sm font-medium leading-relaxed mt-2">
                Elevating brands with premium digital services. Providing high-quality Designs, Pdfs, Resumes, Websites, and Automation.
              </p>
            </div>
            
            {/* Quick Links */}
            <div>
              <h3 className="text-brand-yellow font-black tracking-widest uppercase mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm font-bold">
                <li><Link to="/" className="hover:text-brand-saffron transition-colors">Home & Services</Link></li>
                <li><Link to="/portfolio" className="hover:text-brand-saffron transition-colors">Our Portfolio</Link></li>
                <li><Link to="/pricing" className="hover:text-brand-saffron transition-colors">Subscription Plans</Link></li>
                <li><Link to="/about" className="hover:text-brand-saffron transition-colors">About Us</Link></li>
              </ul>
            </div>
            
            {/* Contact Information */}
            <div>
              <h3 className="text-brand-yellow font-black tracking-widest uppercase mb-4">Contact & Support</h3>
              <ul className="space-y-2 text-sm font-bold">
                <li><a href={`https://wa.me/91${WHATSAPP_NUMBER}`} target="_blank" rel="noopener noreferrer" className="hover:text-brand-saffron transition-colors flex items-center gap-2">WhatsApp Support</a></li>
                <li>Email: hellohiddenmedia@gmail.com</li>
                <li>Available: 24×7</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t-2 border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-bold">
            <p>© {new Date().getFullYear()} Hidden Media Agency. All rights reserved.</p>
            <div className="flex gap-4">
              <span>Made with ❤️ for growing brands</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
