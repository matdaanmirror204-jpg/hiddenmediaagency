import { X, Info } from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';

interface PolicyModalProps {
  onClose: () => void;
  onProceed?: () => void;
}

export function PolicyModal({ onClose, onProceed }: PolicyModalProps) {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    // Prevent background scrolling when modal is open
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, []);

  if (!mounted) return null;

  const modalContent = (
    <div className="fixed inset-0 bg-brand-blue/80 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white text-brand-blue rounded-3xl w-full max-w-lg max-h-[85vh] flex flex-col border-4 border-brand-yellow shadow-[8px_8px_0px_0px_#FF9933] font-sans text-left overflow-hidden m-auto"
      >
        {/* Header */}
        <div className="bg-brand-saffron p-3 md:p-4 flex justify-between items-center border-b-4 border-brand-yellow shrink-0">
          <h2 className="text-sm md:text-lg font-black uppercase tracking-widest text-white flex items-center gap-2">
            <Info className="w-5 h-5" /> Work & Payment Policy
          </h2>
          <button 
            onClick={onClose}
            className="text-white hover:text-brand-blue transition-colors p-1"
          >
            <X className="w-5 h-5 md:w-6 md:h-6" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 md:p-6 overflow-y-auto space-y-4 md:space-y-6 font-medium text-gray-700 text-sm md:text-base">
          <div>
            <h3 className="text-base md:text-lg font-black uppercase text-brand-blue mb-1.5">1. Work Policy</h3>
            <ul className="list-disc pl-5 space-y-1 relative">
              <li>Hum aapka work bilkul aapke instructions aur requirements ke according banayenge.</li>
              <li>Work ko tab tak modify kiya jayega jab tak aap 100% satisfied nahi ho jaate.</li>
              <li>Aapki requirement ke according features, design ya content mein changes karke final delivery di jayegi taaki aapko best result mile.</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-base md:text-lg font-black uppercase text-brand-blue mb-1.5">2. Payment Policy</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Small Work (PDF, poster, editing):</strong> 👉 100% advance</li>
              <li><strong>Large Work (website, advanced setup):</strong> 👉 50% advance + 50% delivery se pehle</li>
              <li>Payment confirm hone ke baad hi work start kiya jayega.</li>
            </ul>
          </div>

          <div>
            <h3 className="text-base md:text-lg font-black uppercase text-brand-blue mb-1.5">3. Refund Policy</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Work start hone ke baad kyunki work aapki requirement ke according customized kiya jata hai, isliye refund applicable nahi hoga.</li>
              <li>Hum aapko fully satisfied karne ke liye best possible changes provide karte rahenge jab tak final delivery complete na ho jaye.</li>
            </ul>
          </div>
        </div>

        {/* Fixed Footer with Button */}
        {onProceed && (
            <div className="p-4 border-t-4 border-brand-yellow bg-gray-50 shrink-0">
              <button
                  onClick={onProceed}
                  className="w-full flex items-center justify-center gap-2 bg-[#25D366] text-white font-black px-4 md:px-6 py-3 md:py-4 rounded-xl border-2 border-[#128C7E] shadow-[4px_4px_0px_0px_#128C7E] uppercase tracking-wide hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_#128C7E] transition-all text-sm md:text-base animate-btn-pulse"
              >
                  Fully Read & Next Step
              </button>
            </div>
        )}
      </motion.div>
    </div>
  );

  return createPortal(modalContent, document.body);
}
