import { useState, useRef, useEffect } from 'react';
import { X, Upload } from 'lucide-react';
import { PortfolioItem } from '../lib/db';

interface PortfolioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<PortfolioItem, 'id'>) => void;
  initialData?: PortfolioItem | null;
}

export function PortfolioModal({ isOpen, onClose, onSave, initialData }: PortfolioModalProps) {
  const [formData, setFormData] = useState<Omit<PortfolioItem, 'id'>>({
    title: '',
    description: '',
    emoji: '🖼️',
    type: 'image',
    category: '',
    price: '',
    keyword: ''
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
        title: '',
        description: '',
        emoji: '🖼️',
        type: 'image',
        category: '',
        price: '',
        keyword: ''
      });
    }
  }, [initialData, isOpen]);

  if (!isOpen) return null;

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, fileData: reader.result as string, link: undefined });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-[8px_8px_0px_0px_#FF9933] w-full max-w-lg border-4 border-brand-blue overflow-hidden flex flex-col max-h-[90vh]">
        <div className="bg-brand-blue text-white px-6 py-4 flex justify-between items-center">
          <h2 className="font-bold text-xl uppercase tracking-wide">
            {initialData ? 'Edit Portfolio Item' : 'Add to Portfolio'}
          </h2>
          <button onClick={onClose} className="hover:text-brand-saffron transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-6 overflow-y-auto font-sans text-brand-blue space-y-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Type</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
                className="w-full border-2 border-brand-blue rounded-md p-2 font-medium"
              >
                <option value="image">Image (Poster)</option>
                <option value="pdf">PDF File (Notes/Resume)</option>
                <option value="link">Website Link</option>
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Category Tag</label>
              <input
                type="text"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full border-2 border-brand-blue rounded-md p-2 font-medium"
                placeholder="e.g. Resume"
              />
            </div>
          </div>

          <div className="flex gap-4">
            <div className="w-24">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Emoji</label>
              <input
                type="text"
                value={formData.emoji}
                onChange={(e) => setFormData({ ...formData, emoji: e.target.value })}
                className="w-full border-2 border-brand-blue rounded-md p-2 text-2xl text-center"
              />
            </div>
            <div className="flex-1">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Title</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full border-2 border-brand-blue rounded-md p-2 font-bold"
                placeholder="Project Title"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full border-2 border-brand-blue rounded-md p-2 font-medium"
              rows={2}
              placeholder="Short description..."
            />
          </div>

          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Pricing Shown</label>
              <input
                type="text"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                className="w-full border-2 border-brand-blue rounded-md p-2 font-bold"
                placeholder="e.g. ₹50"
              />
            </div>
            <div className="flex-1">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Short Code</label>
              <input
                type="text"
                value={formData.keyword || ''}
                onChange={(e) => setFormData({ ...formData, keyword: e.target.value })}
                className="w-full border-2 border-brand-blue rounded-md p-2 font-mono uppercase"
                placeholder="e.g. POST01"
              />
            </div>
          </div>

          {formData.type === 'link' ? (
            <div>
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Website URL</label>
              <input
                type="text"
                value={formData.link || ''}
                onChange={(e) => setFormData({ ...formData, link: e.target.value, fileData: undefined })}
                className="w-full border-2 border-brand-blue rounded-md p-2 font-medium"
                placeholder="https://..."
              />
            </div>
          ) : (
            <div>
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Upload File</label>
              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden" 
                accept={formData.type === 'pdf' ? "application/pdf" : "image/*"}
                onChange={handleFile}
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="w-full border-2 border-dashed border-brand-blue rounded-md p-4 flex flex-col items-center justify-center text-gray-600 hover:bg-blue-50 transition-colors"
                type="button"
              >
                <Upload className="w-8 h-8 mb-2 text-brand-blue" />
                <span className="font-bold">{formData.fileData ? 'File Selected (Click to change)' : 'Click to Upload'}</span>
              </button>
            </div>
          )}
        </div>

        <div className="p-6 border-t-2 border-gray-200 bg-gray-50 flex justify-end gap-4">
          <button
            onClick={onClose}
            className="px-4 py-2 font-bold text-gray-600 hover:text-black uppercase text-sm"
          >
            Cancel
          </button>
          <button
            onClick={() => onSave(formData)}
            className="bg-brand-yellow text-brand-blue px-6 py-2 rounded-md font-bold uppercase shadow-[3px_3px_0px_#003366] hover:translate-x-[1px] hover:-translate-y-[1px] hover:shadow-[4px_4px_0px_#003366]"
          >
            Save Item
          </button>
        </div>
      </div>
    </div>
  );
}
