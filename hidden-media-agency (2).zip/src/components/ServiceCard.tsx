import { motion } from 'motion/react';
import { useAdmin } from '../context/AdminContext';
import { Pencil, Trash2 } from 'lucide-react';
import { ServiceItem } from '../lib/db';
import { WhatsAppButton } from './WhatsAppButton';

export function ServiceCard({ 
  item, 
  onEdit, 
  onDelete 
}: { 
  item: ServiceItem, 
  onEdit: () => void, 
  onDelete: () => void 
}) {
  const { isAdmin } = useAdmin();

  return (
    <div 
      className="bg-white text-brand-blue border-4 border-brand-blue rounded-2xl p-6 transition-all relative flex flex-col h-full hover:shadow-[12px_12px_0px_0px_#FF9933] shadow-[8px_8px_0px_0px_#003366] duration-300 group hover:-translate-y-2 animate-card-float"
    >
      {isAdmin && (
        <div className="absolute top-2 right-2 flex space-x-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
          <button onClick={onEdit} className="p-2 bg-brand-yellow text-brand-blue border-2 border-brand-blue rounded-lg shadow-[2px_2px_0px_0px_#003366] hover:-translate-y-0.5 transition-all" title="Edit">
            <Pencil className="w-4 h-4" />
          </button>
          <button onClick={onDelete} className="p-2 bg-red-500 text-white border-2 border-brand-blue rounded-lg shadow-[2px_2px_0px_0px_#003366] hover:-translate-y-0.5 transition-all" title="Delete">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )}

      {item.category && (
        <div className="text-sm font-black uppercase tracking-widest text-brand-saffron mb-3">
          {item.category}
        </div>
      )}

      <div className="flex items-center gap-4 mb-4">
        <div className="text-4xl bg-brand-yellow p-3 rounded-xl border-2 border-brand-blue shadow-[4px_4px_0px_0px_#003366]">{item.emoji}</div>
        <h3 className="text-xl font-black uppercase tracking-wider leading-tight">{item.title}</h3>
      </div>
      
      <p className="font-bold text-gray-700 mb-6 flex-1 text-sm leading-relaxed">{item.description}</p>
      
      <div className="mt-auto">
        <div className="flex justify-between items-center mb-6">
          <div className="inline-block bg-brand-yellow text-brand-blue font-black px-4 py-2 rounded-xl border-2 border-brand-blue shadow-[2px_2px_0px_0px_#003366] tracking-widest">
            {item.price}
          </div>
          {item.keyword && (
            <div className="text-xs font-black font-mono text-white bg-brand-blue px-3 py-1.5 rounded-lg border-2 border-brand-saffron uppercase">
              Code: <span className="text-brand-yellow font-black">{item.keyword}</span>
            </div>
          )}
        </div>
        
        <WhatsAppButton 
          keyword={item.keyword}
          className="flex w-full items-center justify-center gap-2 bg-[#25D366] text-white font-black px-4 py-3 rounded-xl border-2 border-[#128C7E] shadow-[4px_4px_0px_0px_#128C7E] uppercase tracking-wide hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_#128C7E] transition-all cursor-pointer animate-btn-pulse"
        >
          Pay via WhatsApp
        </WhatsAppButton>
      </div>
    </div>
  );
}


