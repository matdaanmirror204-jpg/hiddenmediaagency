import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { ServiceItem } from '../lib/db';

interface ServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<ServiceItem, 'id'>) => void;
  initialData?: ServiceItem | null;
}

export function ServiceModal({ isOpen, onClose, onSave, initialData }: ServiceModalProps) {
  const [formData, setFormData] = useState<Omit<ServiceItem, 'id'>>({
    title: '',
    description: '',
    emoji: '✨',
    type: 'poster',
    price: '',
    category: '',
    keyword: ''
  });

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
        title: '',
        description: '',
        emoji: '✨',
        type: 'poster',
        price: '',
        category: '',
        keyword: ''
      });
    }
  }, [initialData, isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-[8px_8px_0px_0px_#FF9933] w-full max-w-lg border-4 border-brand-blue overflow-hidden flex flex-col max-h-[90vh]">
        <div className="bg-brand-blue text-white px-6 py-4 flex justify-between items-center">
          <h2 className="font-bold text-xl uppercase tracking-wide">
            {initialData ? 'Edit Service' : 'Add New Service'}
          </h2>
          <button onClick={onClose} className="hover:text-brand-saffron transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-6 overflow-y-auto font-sans text-brand-blue space-y-4">
          <div>
            <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Type</label>
            <select
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
              className="w-full border-2 border-brand-blue rounded-md p-2 font-medium"
            >
              <option value="poster">Poster Making</option>
              <option value="pdf">PDF Design</option>
              <option value="resume">Resume Making</option>
              <option value="website">Website Development</option>
              <option value="marketing">Marketing & Automation</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Category Sub-heading</label>
            <input
              type="text"
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="w-full border-2 border-brand-blue rounded-md p-2 font-medium"
              placeholder="e.g. School & Institute Posters"
            />
          </div>

          <div className="flex gap-4">
            <div className="w-24">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Emoji</label>
              <input
                type="text"
                value={formData.emoji}
                onChange={(e) => setFormData({ ...formData, emoji: e.target.value })}
                className="w-full border-2 border-brand-blue rounded-md p-2 text-2xl text-center"
              />
            </div>
            <div className="flex-1">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Title</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full border-2 border-brand-blue rounded-md p-2 font-bold"
                placeholder="Service Title"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full border-2 border-brand-blue rounded-md p-2 font-medium"
              rows={3}
              placeholder="Detail your service"
            />
          </div>

          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Pricing</label>
              <input
                type="text"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                className="w-full border-2 border-brand-blue rounded-md p-2 font-bold"
                placeholder="e.g. ₹10 per poster"
              />
            </div>
            <div className="flex-1">
              <label className="block text-sm font-bold mb-1 uppercase text-gray-700">Short Code</label>
              <input
                type="text"
                value={formData.keyword || ''}
                onChange={(e) => setFormData({ ...formData, keyword: e.target.value })}
                className="w-full border-2 border-brand-blue rounded-md p-2 font-mono uppercase"
                placeholder="e.g. POSTER10"
              />
            </div>
          </div>
        </div>

        <div className="p-6 border-t-2 border-gray-200 bg-gray-50 flex justify-end gap-4">
          <button
            onClick={onClose}
            className="px-4 py-2 font-bold text-gray-600 hover:text-black uppercase text-sm"
          >
            Cancel
          </button>
          <button
            onClick={() => onSave(formData)}
            className="bg-brand-yellow text-brand-blue px-6 py-2 rounded-md font-bold uppercase shadow-[3px_3px_0px_#003366] hover:translate-x-[1px] hover:-translate-y-[1px] hover:shadow-[4px_4px_0px_#003366]"
          >
            Save Service
          </button>
        </div>
      </div>
    </div>
  );
}
