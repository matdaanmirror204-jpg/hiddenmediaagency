import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

export function Splash({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 2500); // Wait for 2.5 seconds
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 bg-brand-blue z-[200] flex flex-col items-center justify-center overflow-hidden font-sans">
      
      {/* Action Tracker Badge */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.6, ease: 'easeOut' }}
        className="absolute top-10 flex items-center justify-center w-full px-4"
      >
        <div className="bg-brand-saffron text-white border-2 border-brand-yellow shadow-[4px_4px_0px_0px_#FF9933] px-4 sm:px-8 py-2 sm:py-3 rounded-xl whitespace-nowrap">
          <h2 className="text-sm sm:text-lg md:text-2xl lg:text-3xl font-black uppercase tracking-wider md:tracking-widest">
            You are action taker
          </h2>
        </div>
      </motion.div>

      {/* Main Logo Container */}
      <motion.div 
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.7, ease: [0.175, 0.885, 0.32, 1.275] }}
        className="flex flex-col items-center"
      >
        
        <div className="relative flex items-center justify-center w-64 h-64 mb-2">
          {/* Central Logo */}
          <div className="w-20 h-20 bg-brand-yellow rounded-xl border-2 border-brand-saffron flex items-center justify-center shadow-[4px_4px_0px_0px_#FF9933] relative overflow-hidden z-10 z-[2]">
            {/* Decorative shapes */}
            <div className="absolute -top-3 -right-3 w-8 h-8 bg-brand-saffron rounded-full opacity-50"></div>
            <div className="absolute -bottom-3 -left-3 w-8 h-8 bg-brand-blue rounded-full opacity-30"></div>
            <span className="font-black text-4xl text-brand-blue z-10 tracking-tighter">HM</span>
          </div>
          
          {/* Curved Colorful Text */}
          <motion.svg 
            viewBox="0 0 200 200" 
            className="absolute inset-0 w-full h-full animate-[spin_10s_linear_infinite]"
          >
            <path
              id="textPath"
              d="M 100, 100 m -70, 0 a 70,70 0 1,1 140,0 a 70,70 0 1,1 -140,0"
              fill="none"
              stroke="none"
            />
            <text className="text-[17px] font-black uppercase tracking-[4px]" fill="#FFFF00">
              <textPath href="#textPath" startOffset="0%">
                Hidden Media Agency • 
              </textPath>
            </text>
            <text className="text-[17px] font-black uppercase tracking-[4px]" fill="#FF9933">
              <textPath href="#textPath" startOffset="50%">
                Creative Solutions •
              </textPath>
            </text>
          </motion.svg>
        </div>
      </motion.div>

      {/* Loading Bar */}
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="absolute bottom-16 w-64 h-3 bg-brand-blue border-2 border-brand-saffron rounded-full overflow-hidden shadow-[2px_2px_0px_0px_#FF9933]"
      >
        <motion.div 
          initial={{ width: '0%' }}
          animate={{ width: '100%' }}
          transition={{ duration: 2, ease: 'easeInOut' }}
          className="h-full bg-brand-yellow"
        ></motion.div>
      </motion.div>

    </div>
  );
}
