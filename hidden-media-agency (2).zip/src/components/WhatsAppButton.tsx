import { useState } from 'react';
import { getWhatsAppLink } from '../lib/whatsapp';
import { PolicyModal } from './PolicyModal';

interface WhatsAppButtonProps {
  keyword?: string;
  url?: string;
  className?: string;
  children: React.ReactNode;
}

export function WhatsAppButton({ keyword, url, className, children }: WhatsAppButtonProps) {
  const [showPolicy, setShowPolicy] = useState(false);

  const handleProceed = () => {
    setShowPolicy(false);
    const finalUrl = url || getWhatsAppLink(keyword);
    window.open(finalUrl, '_blank');
  };

  return (
    <>
      <button 
        type="button"
        onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            setShowPolicy(true);
        }}
        className={className}
      >
        {children}
      </button>

      {showPolicy && (
        <PolicyModal 
          onClose={() => setShowPolicy(false)}
          onProceed={handleProceed}
        />
      )}
    </>
  );
}
