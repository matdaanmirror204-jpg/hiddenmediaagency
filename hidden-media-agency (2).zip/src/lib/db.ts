import localforage from 'localforage';

localforage.config({
  name: 'HiddenMediaAgency'
});

export interface ServiceItem {
  id: string;
  type: 'poster' | 'pdf' | 'resume' | 'website' | 'marketing';
  category?: string; // e.g. "School & Institute Posters"
  emoji: string;
  title: string;
  description: string;
  price: string;
  keyword?: string;
}

export interface PortfolioItem {
  id: string;
  emoji: string;
  title: string;
  category: string;
  description: string;
  price: string;
  keyword?: string;
  fileData?: string;
  link?: string;
  type: 'image' | 'pdf' | 'link';
}

export interface PlanItem {
  id: string;
  emoji: string;
  title: string;
  subtitle: string;
  price: string;
  duration: string;
  features: string[];
  keyword?: string;
}

export const initDB = async () => {
  const defaultServices: ServiceItem[] = [
    { id: '1', type: 'poster', category: 'Education', emoji: '🏫', title: 'School & Coaching Institute', description: 'School aur coaching ke liye poster design — National Day, events, notices, functions, admissions, exam updates aur social media par apni pehchaan banane ke liye creative posts.', price: '₹10', keyword: 'POSTER01' },
    { id: '2', type: 'poster', category: 'Fitness', emoji: '🏋️', title: 'Gym Branding', description: 'Gym ke liye muscle gain/loss, diet plans, workout, offers aur events ke posters, saath hi social media branding ke liye attractive designs.', price: '₹10', keyword: 'POSTER02' },
    { id: '3', type: 'poster', category: 'Beauty', emoji: '💄', title: 'Beauty Parlour', description: 'Beauty parlour ke liye event posters, festive offers, discounts, product promotion aur social media par reach badhane ke liye creative posts.', price: '₹10', keyword: 'POSTER03' },
    { id: '4', type: 'poster', category: 'Branding', emoji: '📢', title: 'Marketing & Branding', description: 'Business promotion ke liye posters — shop opening, decoration work, mall ya store ads aur social media par strong brand identity ke liye designs.', price: '₹10', keyword: 'POSTER04' },
    { id: '5', type: 'poster', category: 'Business', emoji: '🏢', title: 'Other Business Categories', description: 'Har type ke business ke liye custom poster design — promotion, offers, announcements aur social media par apni pehchaan banane ke liye posters.', price: '₹10', keyword: 'POSTER05' },
    { id: 'yt1', type: 'poster', category: 'Social Media', emoji: '▶️', title: 'YouTube Thumbnail', description: 'High CTR YouTube thumbnails for educational, vlogs, tech, and entertainment channels to boost your views.', price: '₹20', keyword: 'YOUTUBE01' },
    
    { id: '6', type: 'pdf', category: 'Question Papers', emoji: '📝', title: 'Coaching & Institute – Question & PDF Work', description: 'Har exam ke liye questions typing, practice sets, mock papers aur PDFs banaye jaate hain, best formatting aur clear output ke saath.', price: '₹10/page', keyword: 'PDF01' },
    { id: '7', type: 'pdf', category: 'Notes', emoji: '📚', title: 'Notes Making (All Exams)', description: 'School, coaching aur competitive exams ke liye short notes, detailed notes aur revision notes PDF format mein tayaar kiye jaate hain.', price: '₹10/page', keyword: 'PDF02' },
    { id: '8', type: 'pdf', category: 'Exam Content', emoji: '🎯', title: 'Exam Preparation Content', description: 'Objective, subjective, MCQ, previous year questions aur custom exam content PDF ke roop mein provide kiya jaata hai.', price: '₹10/page', keyword: 'PDF03' },
    { id: '9', type: 'pdf', category: 'Study Material', emoji: '📖', title: 'Study Material & Assignments', description: 'Assignments, worksheets, study material aur answer keys PDF format mein, students aur institutes ke liye specially designed.', price: '₹10/page', keyword: 'PDF04' },
    { id: '10', type: 'pdf', category: 'Academic', emoji: '🎓', title: 'Other Academic Work', description: 'Academic related anya kaam jaise syllabus PDFs, practice material, custom content aur institute-specific documents bhi banaye jaate hain.', price: '₹10/page', keyword: 'PDF05' },

    { id: '11', type: 'resume', emoji: '🧑‍💼', title: 'Professional CV (With Photo)', description: 'Standard ATS-friendly resume layout, including professional photo.', price: '₹20', keyword: 'RESUME01' },
    { id: '12', type: 'website', emoji: '🌐', title: 'Ultra-Professional Website Development', description: 'Coaching, institute, beauty parlour, malls aur large clients ke liye ultra-professional website development. Premium design aur fast performance ke saath apne business ko online grow karein.', price: '₹500', keyword: 'WEB01' },
    
    { id: 'm1', type: 'marketing', category: 'Advertising', emoji: '📈', title: 'Professional Ad Setup', description: 'Facebook, Instagram aur Google Ads setup. Aapke target audience tak pahuche aur apne business ya coaching ko fast grow karein. Proper campaign setup with targeting.', price: 'Discuss on WhatsApp', keyword: 'AD_SETUP' },
    { id: 'm2', type: 'marketing', category: 'Automation', emoji: '🤖', title: 'Social Media Automation', description: 'WhatsApp aur Instagram par automation setup karein. Auto-reply se visitors ko instantly jawabo milega, samay bachega aur customer reach aur satisfy hogi. Ham poora setup karke denge.', price: 'Discuss on WhatsApp', keyword: 'MKT_AUTO' },
  ];

  let services = await localforage.getItem<ServiceItem[]>('services');
  if (!services || services.length === 0) {
    await localforage.setItem('services', defaultServices);
  } else {
    // Migration: Update IDs 1-12 to new values without destroying user's other additions
    let updated = false;
    
    // First update existing services 1-12
    services = services.map(srv => {
      if (parseInt(srv.id) >= 1 && parseInt(srv.id) <= 12) {
        const defPost = defaultServices.find(p => p.id === srv.id);
        if (defPost && (srv.title !== defPost.title || srv.description !== defPost.description || srv.price !== defPost.price || srv.keyword !== defPost.keyword)) {
          updated = true;
          return { ...srv, ...defPost };
        }
      }
      return srv;
    });

    // Then append any NEW default services that might be missing completely
    for (const defSrv of defaultServices) {
      if (!services.some(s => s.id === defSrv.id)) {
        services.push(defSrv);
        updated = true;
      }
    }

    if (updated) {
      await localforage.setItem('services', services);
    }
  }
  
  const defaultPortfolio: PortfolioItem[] = [
    // 5x Posters
    { id: 'p1', type: 'image', category: 'Posters', emoji: '🖼️', title: 'Summer Safety Guide', description: 'Coaching/School institute summer safety poster sample.', price: '₹10', keyword: 'PORTFOLIO_P1', link: 'https://storage.googleapis.com/aistudio-genai-prod-canary-user-uploaded-files/a5d7c3bb-9150-482a-a82f-2d174786d790' },
    { id: 'p2', type: 'image', category: 'Posters', emoji: '🖼️', title: 'Recruitment Info Poster', description: 'Information update poster / youtube thumbnail for competitive exam notification.', price: '₹10', keyword: 'PORTFOLIO_P2', link: 'https://storage.googleapis.com/aistudio-genai-prod-canary-user-uploaded-files/2e379ff9-49dd-4848-8df0-10f7aa0251af' },
    { id: 'p3', type: 'image', category: 'Posters', emoji: '🖼️', title: 'Lovely Beauty Parlour', description: 'Promotional service menu poster for beauty parlour and salon services.', price: '₹10', keyword: 'PORTFOLIO_P3', link: 'https://storage.googleapis.com/aistudio-genai-prod-canary-user-uploaded-files/b1dc58aa-7132-4467-bc5b-43d789ca7dbf' },
    { id: 'p4', type: 'image', category: 'Posters', emoji: '🖼️', title: 'Shahi Decoration Center', description: 'Professional advertising poster for event planning, decoration, and flower services.', price: '₹10', keyword: 'PORTFOLIO_P4', link: 'https://storage.googleapis.com/aistudio-genai-prod-canary-user-uploaded-files/36551b9d-fa0a-4ff1-bae8-592d3acc0b7e' },
    { id: 'p5', type: 'image', category: 'Posters', emoji: '🖼️', title: 'Royal Fitness Gym', description: 'Diet plan and promotional chart designed for fitness centers and gyms.', price: '₹10', keyword: 'PORTFOLIO_P5', link: 'https://storage.googleapis.com/aistudio-genai-prod-canary-user-uploaded-files/5fbe6dfa-2d2c-4993-ae4a-1abeb42ff092' },

    // 5x PDFs
    { id: 'pdf1', type: 'pdf', category: 'Education Test', emoji: '📄', title: 'Aaradhya Classes Math Test', description: 'Navodaya Ganit Maha-Sangram mock test document containing 200 questions.', price: '₹10/page', keyword: 'PORTFOLIO_PDF1' },
    { id: 'pdf2', type: 'pdf', category: 'PDF Template', emoji: '📄', title: 'PDF Slot 2', description: 'Admin: Click Edit to upload your sample PDF.', price: '₹10/page', keyword: 'PORTFOLIO_PDF2' },
    { id: 'pdf3', type: 'pdf', category: 'PDF Template', emoji: '📄', title: 'PDF Slot 3', description: 'Admin: Click Edit to upload your sample PDF.', price: '₹10/page', keyword: 'PORTFOLIO_PDF3' },
    { id: 'pdf4', type: 'pdf', category: 'PDF Template', emoji: '📄', title: 'PDF Slot 4', description: 'Admin: Click Edit to upload your sample PDF.', price: '₹10/page', keyword: 'PORTFOLIO_PDF4' },
    { id: 'pdf5', type: 'pdf', category: 'PDF Template', emoji: '📄', title: 'PDF Slot 5', description: 'Admin: Click Edit to upload your sample PDF.', price: '₹10/page', keyword: 'PORTFOLIO_PDF5' },

    // 5x Websites
    { id: 'web1', type: 'link', category: 'Website', emoji: '🌐', title: 'Aaradhya Classes', description: 'Interactive website platform for educational content, test series, and institute overview.', price: '₹500', keyword: 'PORTFOLIO_W1', link: 'https://aaradhyaclasses0512.netlify.app/#' },
    { id: 'web2', type: 'link', category: 'Website', emoji: '🌐', title: 'Website Link Slot 2', description: 'Admin: Click Edit to link the website Demo URL.', price: '₹500', keyword: 'PORTFOLIO_W2', link: 'https://example.com' },
    { id: 'web3', type: 'link', category: 'Website', emoji: '🌐', title: 'Website Link Slot 3', description: 'Admin: Click Edit to link the website Demo URL.', price: '₹500', keyword: 'PORTFOLIO_W3', link: 'https://example.com' },
    { id: 'web4', type: 'link', category: 'Website', emoji: '🌐', title: 'Website Link Slot 4', description: 'Admin: Click Edit to link the website Demo URL.', price: '₹500', keyword: 'PORTFOLIO_W4', link: 'https://example.com' },
    { id: 'web5', type: 'link', category: 'Website', emoji: '🌐', title: 'Website Link Slot 5', description: 'Admin: Click Edit to link the website Demo URL.', price: '₹500', keyword: 'PORTFOLIO_W5', link: 'https://example.com' },

    // 5x Resumes (often PDFs)
    { id: 'res1', type: 'pdf', category: 'Resume', emoji: '🧑‍💼', title: 'Resume Slot 1', description: 'Admin: Click Edit to upload a PDF Resume demo.', price: '₹20', keyword: 'PORTFOLIO_R1' },
    { id: 'res2', type: 'pdf', category: 'Resume', emoji: '🧑‍💼', title: 'Resume Slot 2', description: 'Admin: Click Edit to upload a PDF Resume demo.', price: '₹20', keyword: 'PORTFOLIO_R2' },
    { id: 'res3', type: 'pdf', category: 'Resume', emoji: '🧑‍💼', title: 'Resume Slot 3', description: 'Admin: Click Edit to upload a PDF Resume demo.', price: '₹20', keyword: 'PORTFOLIO_R3' },
    { id: 'res4', type: 'pdf', category: 'Resume', emoji: '🧑‍💼', title: 'Resume Slot 4', description: 'Admin: Click Edit to upload a PDF Resume demo.', price: '₹20', keyword: 'PORTFOLIO_R4' },
    { id: 'res5', type: 'pdf', category: 'Resume', emoji: '🧑‍💼', title: 'Resume Slot 5', description: 'Admin: Click Edit to upload a PDF Resume demo.', price: '₹20', keyword: 'PORTFOLIO_R5' },
  ];
  
  const currentPortfolio = await localforage.getItem<PortfolioItem[]>('portfolio');
  if (!currentPortfolio || currentPortfolio.length === 0) {
    await localforage.setItem('portfolio', defaultPortfolio);
  } else {
    let updated = false;
    const merged = [...currentPortfolio];
    
    for (const def of defaultPortfolio) {
      const existing = merged.find(p => p.id === def.id);
      if (!existing) {
        merged.push(def);
        updated = true;
      } else {
        const index = merged.indexOf(existing);
        let needsUpdate = false;
        const updatedItem = { ...existing };
        
        // Force update of titles and descriptions to ensure user sees latest descriptive metadata
        if (existing.title !== def.title || existing.description !== def.description || existing.price !== def.price || existing.category !== def.category || existing.emoji !== def.emoji) {
            updatedItem.title = def.title;
            updatedItem.description = def.description;
            updatedItem.price = def.price;
            updatedItem.category = def.category;
            updatedItem.emoji = def.emoji;
            needsUpdate = true;
        }

        // Update links ONLY if there is no locally uploaded fileData
        // We only overwrite the link if it was empty, a placeholder, or a previous bot-generated link.
        if (!existing.fileData) {
            if (!existing.link || existing.link === 'https://example.com' || existing.link.includes('storage.googleapis.com/aistudio-genai')) {
                if (existing.link !== def.link) {
                    updatedItem.link = def.link;
                    needsUpdate = true;
                }
            }
        }

        if (needsUpdate) {
            merged[index] = updatedItem;
            updated = true;
        }
      }
    }
    
    if (updated) {
      await localforage.setItem('portfolio', merged);
    }
  }

  const defaultPlans: PlanItem[] = [
    {
      id: 'plan_monthly',
      emoji: '📅',
      title: 'Monthly Plan',
      subtitle: 'Cancel anytime',
      price: '₹200',
      duration: '/ Month',
      features: [
        '🎨 Unlimited poster designs',
        '📄 Unlimited PDFs (notes, notices)',
        '🧑‍💼 Resume design included',
        '💬 Basic web support'
      ],
      keyword: 'PLAN_MONTHLY'
    },
    {
      id: 'plan_yearly',
      emoji: '⭐',
      title: 'Yearly Plan',
      subtitle: 'Best value for money',
      price: '₹2000',
      duration: '/ Year',
      features: [
        '🎨 Unlimited poster designs',
        '📄 Unlimited PDFs (notes, notices)',
        '🧑‍💼 Resume design included',
        '🕸️ Priority web support',
        '🚀 Express Delivery'
      ],
      keyword: 'PLAN_YEARLY'
    }
  ];

  const currentPlans = await localforage.getItem<PlanItem[]>('plans');
  if (!currentPlans || currentPlans.length === 0) {
    await localforage.setItem('plans', defaultPlans);
  }
};
