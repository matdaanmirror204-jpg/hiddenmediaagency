export const WHATSAPP_NUMBER = '9693170770';

export const getWhatsAppLink = (keyword?: string) => {
  const message = keyword 
    ? `Hello Hidden Media Agency 👋\nI want to order: ${keyword}`
    : `Hello Hidden Media Agency 👋\nI want to place an order.`;
  return `https://wa.me/91${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
};
