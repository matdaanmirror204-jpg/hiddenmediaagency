import { motion } from 'motion/react';
import { Helmet } from 'react-helmet-async';

export default function About() {
  return (
    <div className="py-16 max-w-4xl mx-auto text-center">
      <Helmet>
        <title>About Us - Hidden Media Agency</title>
        <meta name="description" content="Learn more about Hidden Media Agency, our vision, and how we help businesses grow with top-notch digital solutions." />
      </Helmet>
      <motion.div
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="bg-white text-brand-blue border-4 border-brand-saffron rounded-3xl p-8 md:p-16 shadow-[12px_12px_0px_0px_#FF9933] relative overflow-hidden"
      >
        <span className="text-6xl mb-6 block drop-shadow-[4px_4px_0px_#FF9933]">🏢</span>
        <h1 className="text-4xl md:text-5xl font-black uppercase tracking-widest text-brand-blue mb-10">
          About Hidden Media
        </h1>
        
        <div className="space-y-6 text-lg font-bold text-gray-700 text-left leading-relaxed">
          <p>
            Welcome to <strong className="text-brand-blue font-black uppercase">Hidden Media Agency</strong> - your one-stop solution for professional design and development needs.
          </p>
          <p>
            Whether you are a School seeking admission posters, a Coaching Institute needing perfectly crafted question paper PDFs, or a Business launching a fresh website, we bring your vision to life.
          </p>
          <p>
            With a focus on visually appealing, fast, and reliable digital presence, we deliver end-to-end creative solutions. We believe in high-quality design paired with straightforward, transparent pricing.
          </p>
          
          <div className="mt-16 pt-12 border-t-4 border-brand-saffron">
            <h2 className="text-3xl font-black uppercase text-brand-blue mb-8 text-center tracking-wider">Why Choose Us?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-50 p-8 rounded-2xl border-2 border-brand-blue hover:-translate-y-1 transition-transform shadow-[4px_4px_0px_0px_#FF9933]">
                <span className="text-4xl mb-4 block drop-shadow-[2px_2px_0px_#003366]">1️⃣</span>
                <h3 className="font-black text-xl text-brand-blue uppercase mb-3 tracking-widest">100% Satisfaction</h3>
                <p className="text-sm font-bold text-gray-600">We keep refining your work until you are fully satisfied with the final result. Your happiness is our top priority.</p>
              </div>
              <div className="bg-gray-50 p-8 rounded-2xl border-2 border-brand-blue hover:-translate-y-1 transition-transform shadow-[4px_4px_0px_0px_#FF9933]">
                <span className="text-4xl mb-4 block drop-shadow-[2px_2px_0px_#003366]">2️⃣</span>
                <h3 className="font-black text-xl text-brand-blue uppercase mb-3 tracking-widest">Fast turnaround</h3>
                <p className="text-sm font-bold text-gray-600">Strict adherence to delivery timelines. Quality digital assets delivered when you need them.</p>
              </div>
              <div className="bg-gray-50 p-8 rounded-2xl border-2 border-brand-blue hover:-translate-y-1 transition-transform shadow-[4px_4px_0px_0px_#FF9933]">
                <span className="text-4xl mb-4 block drop-shadow-[2px_2px_0px_#003366]">3️⃣</span>
                <h3 className="font-black text-xl text-brand-blue uppercase mb-3 tracking-widest">Clear Pricing</h3>
                <p className="text-sm font-bold text-gray-600">No hidden fees, no complicated quotations. Simple upfront pricing for standard works, and transparent milestones for larger projects.</p>
              </div>
              <div className="bg-gray-50 p-8 rounded-2xl border-2 border-brand-blue hover:-translate-y-1 transition-transform shadow-[4px_4px_0px_0px_#FF9933]">
                <span className="text-4xl mb-4 block drop-shadow-[2px_2px_0px_#003366]">4️⃣</span>
                <h3 className="font-black text-xl text-brand-blue uppercase mb-3 tracking-widest">Direct Comms</h3>
                <p className="text-sm font-bold text-gray-600">Easy coordination straight through WhatsApp. Quick responses exactly where you are already comfortable.</p>
              </div>
            </div>
          </div>
          
          <div className="mt-16 pt-12 border-t-4 border-brand-saffron">
            <h2 className="text-3xl font-black uppercase text-brand-blue mb-8 text-center tracking-wider">Frequently Asked Questions</h2>
            <div className="space-y-6 text-left">
              <div className="bg-brand-yellow text-brand-blue border-4 border-brand-blue p-6 rounded-2xl shadow-[6px_6px_0px_0px_#003366]">
                <h3 className="font-black text-lg uppercase tracking-wider mb-2 flex items-center gap-3"><span className="text-2xl drop-shadow-[2px_2px_0px_#FF9933]">❓</span> How do I place an order?</h3>
                <p className="text-sm font-bold opacity-90">Simply browse our services on the Home or Portfolio page, click "Order on WhatsApp", and share your exact requirements with us directly.</p>
              </div>
              <div className="bg-brand-saffron text-white border-4 border-brand-blue p-6 rounded-2xl shadow-[6px_6px_0px_0px_#003366]">
                <h3 className="font-black text-lg uppercase tracking-wider mb-2 flex items-center gap-3"><span className="text-2xl drop-shadow-[2px_2px_0px_#FFFF00]">❓</span> Do you offer refunds?</h3>
                <p className="text-sm font-bold opacity-90">Since our work is custom-crafted according to your needs, we do not offer refunds once work starts. However, we will revise and modify the project until you are 100% satisfied.</p>
              </div>
              <div className="bg-white text-brand-blue border-4 border-brand-blue p-6 rounded-2xl shadow-[6px_6px_0px_0px_#003366]">
                <h3 className="font-black text-lg uppercase tracking-wider mb-2 flex items-center gap-3"><span className="text-2xl drop-shadow-[2px_2px_0px_#FF9933]">❓</span> What is the payment process?</h3>
                <p className="text-sm font-bold opacity-90">For small tasks (Posters, Resumes, PDFs), we require 100% upfront payment. For large scale works (Websites, Ads Automation), we take 50% advance and 50% before final delivery.</p>
              </div>
              <div className="bg-white text-brand-blue border-4 border-brand-blue p-6 rounded-2xl shadow-[6px_6px_0px_0px_#003366]">
                <h3 className="font-black text-lg uppercase tracking-wider mb-2 flex items-center gap-3"><span className="text-2xl drop-shadow-[2px_2px_0px_#FF9933]">❓</span> How much time does it take?</h3>
                <p className="text-sm font-bold opacity-90">Most small tasks are delivered within 24 hours. Websites and large setups usually take 3 to 7 working days depending on the complexity.</p>
              </div>
            </div>
          </div>
          
          <div className="pt-12 mt-12 border-t-4 border-brand-saffron flex justify-center gap-8 text-4xl drop-shadow-[2px_2px_0px_#FF9933]">
            <span title="Creativity">🎨</span>
            <span title="Speed">🚀</span>
            <span title="Trust">🤝</span>
            <span title="Quality">✨</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
