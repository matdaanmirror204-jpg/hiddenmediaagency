import { motion } from 'motion/react';
import { Helmet } from 'react-helmet-async';
import { Send, Phone } from 'lucide-react';
import { useState } from 'react';
import { WHATSAPP_NUMBER } from '../lib/whatsapp';
import { WhatsAppButton } from '../components/WhatsAppButton';
import { PolicyModal } from '../components/PolicyModal';

export default function Contact() {
  const [formState, setFormState] = useState({ name: '', message: '' });
  const [showPolicy, setShowPolicy] = useState(false);
  const [waUrl, setWaUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = `Hello Hidden Media Agency 👋\nMy Name is: ${formState.name}\nMessage: ${formState.message}`;
    const url = `https://wa.me/91${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
    setWaUrl(url);
    setShowPolicy(true);
  };

  return (
    <div className="py-12 max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center font-sans">
      <Helmet>
        <title>Contact Us - Hidden Media Agency</title>
        <meta name="description" content="Get in touch with Hidden Media Agency. Contact us via WhatsApp or drop a message to boost your online presence." />
      </Helmet>
      {/* Contact Information */}
      <motion.div initial={{ x: -30, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
        <h1 className="text-4xl md:text-5xl font-black uppercase tracking-widest text-brand-yellow drop-shadow-[2px_2px_0px_#FF9933] mb-6">
          Get in Touch
        </h1>
        <p className="text-lg text-white font-bold leading-relaxed mb-10 max-w-lg">
          Have a project in mind? Looking for bulk orders for your school or institute? Send us a direct message on WhatsApp!
        </p>

        <WhatsAppButton 
          url={`https://wa.me/91${WHATSAPP_NUMBER}`}
          className="inline-flex items-center justify-center gap-3 bg-[#25D366] text-white font-black uppercase px-8 py-4 rounded-xl border-4 border-[#128C7E] shadow-[6px_6px_0px_0px_#128C7E] transition-all hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_#128C7E] w-full sm:w-auto tracking-wider animate-btn-pulse"
        >
          <Phone className="w-5 h-5" /> WhatsApp Us
        </WhatsAppButton>
      </motion.div>

      {/* Contact Form */}
      <motion.div 
        initial={{ x: 30, opacity: 0 }} 
        animate={{ x: 0, opacity: 1 }}
        className="bg-white text-brand-blue rounded-3xl p-8 md:p-10 border-4 border-brand-saffron shadow-[12px_12px_0px_0px_#FF9933] relative overflow-hidden"
      >
        <form 
          onSubmit={handleSubmit}
          className="flex flex-col gap-6 relative z-10"
        >
          <div>
            <label className="block text-sm font-black text-gray-700 uppercase tracking-widest mb-3">Full Name</label>
            <input 
              type="text" 
              name="name"
              required
              value={formState.name}
              onChange={e => setFormState({...formState, name: e.target.value})}
              className="w-full bg-gray-50 border-2 border-brand-blue text-brand-blue rounded-xl p-4 font-bold outline-none focus:border-brand-saffron transition-all"
              placeholder="Your Name"
            />
          </div>
          
          <div>
            <label className="block text-sm font-black text-gray-700 uppercase tracking-widest mb-3">Your Message</label>
            <textarea 
              name="message"
              required
              rows={5}
              value={formState.message}
              onChange={e => setFormState({...formState, message: e.target.value})}
              className="w-full bg-gray-50 border-2 border-brand-blue text-brand-blue rounded-xl p-4 font-bold outline-none focus:border-brand-saffron transition-all resize-none"
              placeholder="What do you need?"
            ></textarea>
          </div>
          
          <button 
            type="submit"
            className="mt-4 flex justify-center items-center gap-3 bg-[#25D366] text-white border-2 border-[#128C7E] font-black tracking-widest uppercase py-4 rounded-xl shadow-[4px_4px_0px_0px_#128C7E] transition-all hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_#128C7E] w-full animate-btn-pulse"
          >
            <Send className="w-5 h-5" /> Send via WhatsApp
          </button>
        </form>
      </motion.div>

      {showPolicy && (
        <PolicyModal 
          onClose={() => setShowPolicy(false)}
          onProceed={() => {
              setShowPolicy(false);
              window.open(waUrl, '_blank');
          }}
        />
      )}
    </div>
  );
}
