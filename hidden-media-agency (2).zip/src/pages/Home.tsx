import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'motion/react';
import localforage from 'localforage';
import { ServiceItem } from '../lib/db';
import { ServiceCard } from '../components/ServiceCard';
import { ServiceModal } from '../components/ServiceModal';
import { PolicyModal } from '../components/PolicyModal';
import { useAdmin } from '../context/AdminContext';
import { PlusCircle, Info, Star, X } from 'lucide-react';

export default function Home() {
  const { isAdmin } = useAdmin();
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ServiceItem | null>(null);
  
  const [isProcessModalOpen, setIsProcessModalOpen] = useState(false);
  const [isReviewsModalOpen, setIsReviewsModalOpen] = useState(false);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    const data = await localforage.getItem<ServiceItem[]>('services') || [];
    setServices(data);
  };

  const handleSave = async (formData: Omit<ServiceItem, 'id'>) => {
    let updated: ServiceItem[];
    if (editingItem) {
      updated = services.map(s => s.id === editingItem.id ? { ...formData, id: s.id } : s);
    } else {
      updated = [...services, { ...formData, id: Date.now().toString() }];
    }
    await localforage.setItem('services', updated);
    setServices(updated);
    setIsModalOpen(false);
    setEditingItem(null);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this service?')) return;
    const updated = services.filter(s => s.id !== id);
    await localforage.setItem('services', updated);
    setServices(updated);
  };

  const renderSection = (title: string, emoji: string, type: string) => {
    const filtered = services.filter(s => s.type === type);
    if (filtered.length === 0 && !isAdmin) return null;

    return (
      <div key={type} className="mb-20">
        <div className="flex items-center gap-4 mb-10 pb-4 border-b-4 border-white/20">
          <span className="text-3xl bg-white text-brand-blue p-3 rounded-xl border-4 border-brand-saffron shadow-[4px_4px_0px_0px_#FF9933]">{emoji}</span>
          <h2 className="text-3xl font-black text-white tracking-widest uppercase text-shadow-sm">{title}</h2>
        </div>
        <motion.div 
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-50px" }}
          variants={{
            hidden: { opacity: 0 },
            show: {
              opacity: 1,
              transition: { staggerChildren: 0.15 }
            }
          }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {filtered.map((item) => (
            <motion.div
              variants={{
                hidden: { opacity: 0, y: 40, scale: 0.8 },
                show: { 
                  opacity: 1, 
                  y: 0, 
                  scale: 1,
                  transition: { type: "spring", stiffness: 300, damping: 24 }
                }
              }}
              key={item.id}
            >
              <ServiceCard 
                item={item} 
                onEdit={() => { setEditingItem(item); setIsModalOpen(true); }}
                onDelete={() => handleDelete(item.id)}
              />
            </motion.div>
          ))}
        </motion.div>
      </div>
    );
  };

  return (
    <div className="py-8 font-sans">
      <Helmet>
        <title>Hidden Media Agency | Premium Digital Services</title>
        <meta name="description" content="Welcome to Hidden Media Agency. We provide top-notch digital services, web development, and media solutions." />
      </Helmet>
      {/* Hero Motive Section */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="max-w-4xl mx-auto mb-16"
      >
        <div className="bg-white text-brand-blue p-8 md:p-14 rounded-3xl border-4 border-brand-saffron shadow-[12px_12px_0px_0px_#FF9933] text-center relative">
          
          <h1 className="text-4xl md:text-6xl font-black uppercase tracking-widest text-brand-blue mb-6">
            Hidden Media Agency
          </h1>
          <p className="text-lg md:text-xl text-gray-700 font-bold mb-10 leading-relaxed max-w-3xl mx-auto">
            Elevating brands with premium digital services. Providing high-quality Poster Designs, PDFs, ATS-friendly Resumes, Websites, and Next-Gen Automation specifically tailored for Coaching Institutes, Schools, and Growing Businesses.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 relative z-10">
            <button 
              onClick={() => setIsProcessModalOpen(true)}
              className="flex items-center justify-center gap-2 w-full sm:w-auto bg-brand-yellow hover:bg-white text-brand-blue font-black px-8 py-4 rounded-xl border-2 border-brand-blue shadow-[4px_4px_0px_0px_#003366] transition-all hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_#003366] animate-btn-pulse uppercase overflow-hidden"
            >
              <Info className="w-5 h-5" /> Work & Payment Process
            </button>
            <button 
              onClick={() => setIsReviewsModalOpen(true)}
              className="flex items-center justify-center gap-2 w-full sm:w-auto bg-brand-saffron hover:bg-white border-2 border-brand-blue text-brand-blue font-black px-8 py-4 rounded-xl shadow-[4px_4px_0px_0px_#003366] transition-all hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_#003366] animate-btn-pulse uppercase"
            >
              <Star className="w-5 h-5" /> Customer Reviews
            </button>
          </div>
        </div>
      </motion.div>

      {/* Trust Stats Bar */}
      <div className="flex flex-wrap justify-center gap-4 md:gap-8 mb-20 max-w-5xl mx-auto">
        <div className="bg-white border-4 border-brand-yellow text-brand-blue px-8 py-4 rounded-2xl flex items-center gap-4 hover:-translate-y-1 transition-all shadow-[6px_6px_0px_0px_#FF9933]">
          <div className="text-3xl">🔥</div>
          <div>
            <div className="font-black text-2xl leading-none">500+</div>
            <div className="text-sm font-bold text-brand-saffron uppercase tracking-widest mt-1">Projects Done</div>
          </div>
        </div>
        <div className="bg-white border-4 border-brand-yellow text-brand-blue px-8 py-4 rounded-2xl flex items-center gap-4 hover:-translate-y-1 transition-all shadow-[6px_6px_0px_0px_#FF9933]">
          <div className="text-3xl">⚡</div>
          <div>
            <div className="font-black text-2xl leading-none">Fast</div>
            <div className="text-sm font-bold text-brand-saffron uppercase tracking-widest mt-1">Digital Delivery</div>
          </div>
        </div>
        <div className="bg-white border-4 border-brand-yellow text-brand-blue px-8 py-4 rounded-2xl flex items-center gap-4 hover:-translate-y-1 transition-all shadow-[6px_6px_0px_0px_#FF9933]">
          <div className="text-3xl">💯</div>
          <div>
            <div className="font-black text-2xl leading-none">100%</div>
            <div className="text-sm font-bold text-brand-saffron uppercase tracking-widest mt-1">Satisfaction</div>
          </div>
        </div>
      </div>

      {/* Admin Quick Actions */}
      {isAdmin && (
        <div className="mb-12 text-right">
          <button
            onClick={() => { setEditingItem(null); setIsModalOpen(true); }}
            className="inline-flex items-center gap-2 bg-brand-yellow text-brand-blue border-2 border-brand-blue px-6 py-3 rounded-xl font-black uppercase shadow-[4px_4px_0px_0px_#FF9933] hover:-translate-y-1 transition-all"
          >
            <PlusCircle className="w-5 h-5" /> Add New Service
          </button>
        </div>
      )}

      {/* Services Sections */}
      {renderSection("Poster Making", "🎨", "poster")}
      {renderSection("PDF Design", "📄", "pdf")}
      {renderSection("Resume Making", "🧑‍💼", "resume")}
      {renderSection("Website Development", "🌐", "website")}
      {renderSection("Marketing & Automation", "🚀", "marketing")}

      <ServiceModal
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingItem(null); }}
        onSave={handleSave}
        initialData={editingItem}
      />

      {/* Process Modal */}
      {isProcessModalOpen && (
        <PolicyModal onClose={() => setIsProcessModalOpen(false)} />
      )}

      {/* Reviews Modal */}
      {isReviewsModalOpen && (
        <div className="fixed inset-0 bg-brand-blue/90 z-50 flex items-center justify-center p-4 py-8">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white text-brand-blue rounded-3xl w-full max-w-2xl max-h-full overflow-y-auto border-4 border-brand-saffron shadow-[12px_12px_0px_0px_#FF9933] flex flex-col"
          >
            <div className="bg-brand-saffron p-4 flex justify-between items-center border-b-4 border-brand-yellow sticky top-0 z-10">
              <h2 className="text-xl font-black uppercase tracking-wider text-white flex items-center gap-2">
                <Star className="w-6 h-6 text-brand-yellow" fill="currentColor" /> Customer Reviews
              </h2>
              <button 
                onClick={() => setIsReviewsModalOpen(false)}
                className="text-white hover:text-brand-blue transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              {[
                { name: "Rahul Sharma", role: "Coaching Institute Owner", review: "Amazing work! Inhone mere institute ke liye poster aur notice design kiya. Bahut hi professional aur fast service. 100% Recommended." },
                { name: "Priya Verma", role: "Beauty Parlour Business", review: "Mere parlour ke website aur promotional posts ekdum top class banaye hain. Inki team bahut supportive hai aur jab tak main satisfy nahi hui tab tak changes kiye. Great agency!" },
                { name: "Ankit Kumar", role: "Fitness Trainer", review: "Gym branding and social media automation setup worked like magic. My inquiries have doubled. Fantastic communication and output quality." },
                { name: "Sneha Gupta", role: "Teacher", review: "Notes aur Mock test PDFs ki quality bahut achi thi. Typing format ekdum clean hai aur error-free work. Best media agency I have worked with." },
                { name: "Vikash Singh", role: "Job Seeker", review: "Mera resume itna professional banaya ki mujhe turant interview calls aane lage. ATS friendly aur premium design. Thank you Hidden Media Agency!" },
              ].map((rev, i) => (
                <div key={i} className="bg-gray-50 border-2 border-brand-blue rounded-2xl p-6 shadow-[4px_4px_0px_0px_#FF9933]">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-black text-xl text-brand-blue tracking-wide">{rev.name}</h4>
                      <p className="text-sm text-brand-saffron font-bold uppercase">{rev.role}</p>
                    </div>
                    <div className="text-brand-yellow flex text-2xl drop-shadow-[1px_1px_0px_#003366]">
                      ★★★★★
                    </div>
                  </div>
                  <p className="text-gray-700 font-bold italic leading-relaxed mt-2">"{rev.review}"</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      )}

      {/* Global Call to Action block */}
      <div className="mt-28 text-center bg-white text-brand-blue p-10 md:p-16 rounded-3xl border-4 border-brand-saffron shadow-[12px_12px_0px_0px_#FF9933] relative">
        <h2 className="text-3xl md:text-5xl font-black uppercase tracking-widest mb-6">Ready to upgrade your brand?</h2>
        <p className="text-lg text-gray-700 font-bold mb-10 max-w-2xl mx-auto">
          Need a specific design, bulk pdf typing, or a custom website that's not listed above? Send us a direct message and let's get it done.
        </p>
        <button 
          onClick={() => window.location.href = '/contact'}
          className="bg-[#25D366] text-white font-black px-8 py-4 rounded-xl text-lg shadow-[6px_6px_0px_0px_#128C7E] border-2 border-[#128C7E] transition-all hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_#128C7E] inline-flex items-center gap-2 animate-btn-pulse uppercase"
        >
           Discuss Your Project
        </button>
      </div>
    </div>
  );
}
