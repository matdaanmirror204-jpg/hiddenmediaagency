import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAdmin } from '../context/AdminContext';
import { Shield, KeyRound, User } from 'lucide-react';
import { motion } from 'motion/react';
import { Helmet } from 'react-helmet-async';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const navigate = useNavigate();
  const { login, isAdmin, logout } = useAdmin();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(username, password)) {
      navigate('/');
    } else {
      setError(true);
    }
  };

  if (isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center py-20 px-4">
        <Helmet>
          <title>Admin Dashboard - Hidden Media Agency</title>
          <meta name="robots" content="noindex, nofollow" />
        </Helmet>
        <div className="bg-white text-brand-blue p-8 rounded-3xl border-4 border-brand-blue shadow-[8px_8px_0px_0px_#FF9933] max-w-sm w-full font-sans">
          <Shield className="w-16 h-16 mx-auto mb-4 text-[#25D366]" />
          <h2 className="text-2xl font-black uppercase tracking-wider mb-6 text-center">Admin Status: Active</h2>
          <button 
            onClick={logout}
            className="w-full bg-red-600 text-white font-black py-4 rounded-xl border-2 border-red-800 shadow-[4px_4px_0px_0px_#7f1d1d] uppercase hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_#7f1d1d] transition-all"
          >
            Logout
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center py-20 px-4">
      <Helmet>
        <title>Admin Login - Hidden Media Agency</title>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white text-brand-blue rounded-3xl p-8 border-4 border-brand-blue shadow-[12px_12px_0px_0px_#FF9933] max-w-md w-full font-sans relative"
      >
        <div className="flex justify-center mb-8 relative z-10">
          <div className="bg-brand-blue p-4 rounded-full border-4 border-brand-yellow shadow-[4px_4px_0px_0px_#FF9933]">
            <Shield className="w-10 h-10 text-white" />
          </div>
        </div>
        
        <h1 className="text-3xl font-black text-center uppercase tracking-widest text-brand-blue mb-10 relative z-10">Admin Access</h1>
        
        <form onSubmit={handleLogin} className="space-y-6 relative z-10">
          <div>
            <label className="block text-sm font-black mb-2 uppercase text-gray-700 tracking-widest flex items-center gap-2">
              <User className="w-4 h-4 text-brand-saffron" /> Admin Username
            </label>
            <input 
              type="text" 
              required
              value={username}
              onChange={e => setUsername(e.target.value)}
              className="w-full bg-gray-50 border-2 border-brand-blue rounded-xl p-4 font-bold outline-none focus:border-brand-saffron transition-all text-brand-blue"
              placeholder="Enter username"
            />
          </div>
          
          <div>
            <label className="block text-sm font-black mb-2 uppercase text-gray-700 tracking-widest flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-brand-saffron" /> Password
            </label>
            <input 
              type="password" 
              required
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full bg-gray-50 border-2 border-brand-blue rounded-xl p-4 font-bold outline-none focus:border-brand-saffron transition-all text-brand-blue"
              placeholder="Enter password"
            />
          </div>

          {error && (
            <p className="text-red-600 font-bold text-center text-sm uppercase">
              Invalid credentials. Please try again.
            </p>
          )}

          <button 
            type="submit"
            className="w-full bg-brand-yellow text-brand-blue border-2 border-brand-blue font-black tracking-widest uppercase py-4 rounded-xl shadow-[4px_4px_0px_0px_#003366] hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_#003366] transition-all mt-6"
          >
            Authenticate
          </button>
        </form>
      </motion.div>
    </div>
  );
}
