import { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'motion/react';
import localforage from 'localforage';
import { PortfolioItem } from '../lib/db';
import { PortfolioModal } from '../components/PortfolioModal';
import { useAdmin } from '../context/AdminContext';
import { PlusCircle, ExternalLink, FileText, Pencil, Trash2, X, MessageCircle } from 'lucide-react';
import { WhatsAppButton } from '../components/WhatsAppButton';

export default function Portfolio() {
  const { isAdmin } = useAdmin();
  const [items, setItems] = useState<PortfolioItem[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<PortfolioItem | null>(null);
  const [filter, setFilter] = useState<'all' | 'image' | 'pdf' | 'link'>('all');
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    const data = await localforage.getItem<PortfolioItem[]>('portfolio') || [];
    setItems(data);
  };

  const handleSave = async (formData: Omit<PortfolioItem, 'id'>) => {
    let updated: PortfolioItem[];
    if (editingItem) {
      updated = items.map(s => s.id === editingItem.id ? { ...formData, id: s.id } : s);
    } else {
      updated = [...items, { ...formData, id: Date.now().toString() }];
    }
    await localforage.setItem('portfolio', updated);
    setItems(updated);
    setIsModalOpen(false);
    setEditingItem(null);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this portfolio item?')) return;
    const updated = items.filter(s => s.id !== id);
    await localforage.setItem('portfolio', updated);
    setItems(updated);
  };

  const filteredItems = items.filter(item => filter === 'all' || item.type === filter);

  return (
    <div className="py-8 font-sans">
      <Helmet>
        <title>Portfolio - Hidden Media Agency</title>
        <meta name="description" content="Explore our rich portfolio of successful projects spanning web development, graphic design, content creation, and more." />
      </Helmet>
      <div className="flex flex-col md:flex-row justify-between items-center mb-16 gap-8 text-center md:text-left pt-6">
        <div>
          <h1 className="text-4xl md:text-5xl font-black uppercase tracking-widest text-brand-yellow drop-shadow-[2px_2px_0px_#FF9933] mb-4">
            Our Portfolio
          </h1>
          <p className="text-white font-bold text-lg max-w-xl opacity-90">Explore our finest work across digital design, development, and branding.</p>
        </div>

        <div className="flex bg-brand-yellow rounded-xl border-4 border-brand-blue shadow-[6px_6px_0px_0px_#003366] overflow-hidden flex-wrap md:flex-nowrap">
          {(['all', 'image', 'pdf', 'link'] as const).map((f, i, arr) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`flex-1 px-4 py-3 md:px-6 md:py-4 font-black uppercase tracking-widest text-xs md:text-sm transition-all duration-300 ${
                i !== arr.length - 1 ? 'border-b-4 md:border-b-0 md:border-r-4 border-brand-blue' : ''
              } ${
                filter === f 
                  ? 'bg-brand-blue text-white' 
                  : 'text-brand-blue hover:bg-brand-blue/10'
              }`}
            >
              {f === 'all' ? 'All' : f === 'image' ? '🖼️ Posters' : f === 'pdf' ? '📄 PDFs' : '🌐 Websites'}
            </button>
          ))}
        </div>
      </div>

      {isAdmin && (
        <div className="mb-12 text-right">
          <button
            onClick={() => { setEditingItem(null); setIsModalOpen(true); }}
            className="inline-flex items-center gap-2 bg-brand-yellow text-brand-blue border-4 border-brand-blue px-6 py-3 rounded-xl font-black uppercase tracking-wider shadow-[4px_4px_0px_0px_#FF9933] hover:-translate-y-1 transition-all"
          >
            <PlusCircle className="w-5 h-5" /> Add Portfolio Item
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
        <AnimatePresence mode="popLayout">
          {filteredItems.map((item, index) => (
            <motion.div
              layout
              initial={{ opacity: 0, scale: 0.8, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, transition: { duration: 0.2, delay: 0 } }}
              transition={{ 
                type: "spring", stiffness: 300, damping: 24,
                delay: index * 0.1 
              }}
              key={item.id}
              className="bg-white text-brand-blue border-4 border-brand-blue rounded-3xl overflow-hidden flex flex-col relative transition-transform duration-300 shadow-[8px_8px_0px_0px_#003366] hover:-translate-y-2 group"
            >
              {isAdmin && (
                <div className="absolute top-2 right-2 flex space-x-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => { setEditingItem(item); setIsModalOpen(true); }} className="p-2 bg-brand-yellow text-brand-blue rounded-lg border-2 border-brand-blue hover:-translate-y-0.5 shadow-[2px_2px_0px_0px_#003366] transition-all">
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleDelete(item.id)} className="p-2 bg-red-500 text-white rounded-lg border-2 border-brand-blue hover:-translate-y-0.5 shadow-[2px_2px_0px_0px_#003366] transition-all">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}

              <div className="h-56 bg-brand-blue/5 flex items-center justify-center relative border-b-4 border-brand-blue overflow-hidden">
                {item.type === 'image' && (item.fileData || item.link) ? (
                  <img 
                    src={item.fileData || item.link} 
                    alt={item.title} 
                    className="w-full h-full object-cover cursor-pointer group-hover:scale-105 transition-transform duration-500"
                    onClick={() => setSelectedItem(item)}
                  />
                ) : item.type === 'pdf' ? (
                  <FileText className="w-20 h-20 text-brand-blue/30" />
                ) : (
                  <ExternalLink className="w-20 h-20 text-brand-blue/30" />
                )}
                <div className="absolute top-3 left-3 bg-brand-yellow text-brand-blue border-2 border-brand-blue text-xs font-black px-3 py-1.5 rounded-lg tracking-widest uppercase shadow-[2px_2px_0px_0px_#003366]">
                  {item.category}
                </div>
              </div>

              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-3xl bg-gray-50 border-2 border-brand-blue shadow-[2px_2px_0px_0px_#003366] p-2 rounded-xl">{item.emoji}</span>
                  <h3 className="text-xl font-black uppercase tracking-wider">{item.title}</h3>
                </div>
                <p className="font-bold text-gray-700 mb-6 flex-1 text-sm leading-relaxed">{item.description}</p>
                
                <div className="flex flex-col gap-4 mt-auto">
                  <div className="flex justify-between items-center">
                    <div className="bg-brand-saffron text-white font-black px-4 py-2 border-2 border-brand-blue shadow-[2px_2px_0px_0px_#003366] rounded-xl text-sm tracking-widest">
                      {item.price}
                    </div>
                    {item.keyword && (
                      <div className="text-xs font-black font-mono text-white bg-brand-blue px-3 py-1.5 rounded-lg border-2 border-brand-saffron uppercase shadow-[2px_2px_0px_0px_#FF9933]">
                        Code: <span className="text-brand-yellow">{item.keyword}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex flex-col gap-2">
                    <WhatsAppButton 
                      keyword={item.keyword}
                      className="flex w-full items-center justify-center gap-2 bg-[#25D366] text-white font-black py-3 rounded-xl shadow-[4px_4px_0px_0px_#128C7E] border-2 border-[#128C7E] transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer text-sm uppercase tracking-wider animate-btn-pulse"
                    >
                      <MessageCircle className="w-5 h-5" /> Order on WhatsApp
                    </WhatsAppButton>
                    <div className="flex gap-2">
                      {item.type === 'pdf' && item.fileData && (
                        <a href={item.fileData} download={`${item.title}.pdf`} className="flex-1 text-center text-xs font-black uppercase tracking-widest bg-gray-100 text-brand-blue border-2 border-brand-blue shadow-[2px_2px_0px_0px_#003366] px-2 py-3 rounded-xl hover:bg-gray-200 transition-all hover:-translate-y-0.5">
                          Download PDF
                        </a>
                      )}
                      {item.type === 'link' && item.link && (
                        <a href={item.link} target="_blank" rel="noopener noreferrer" className="flex-1 text-center text-xs font-black uppercase tracking-widest bg-brand-blue text-white border-2 border-brand-saffron shadow-[2px_2px_0px_0px_#FF9933] px-2 py-3 rounded-xl hover:bg-brand-blue/90 transition-all hover:-translate-y-0.5">
                          Visit Site
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <PortfolioModal
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingItem(null); }}
        onSave={handleSave}
        initialData={editingItem}
      />

      {/* Lightbox for zooming images */}
      <AnimatePresence>
        {selectedItem && (selectedItem.fileData || selectedItem.link) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-brand-blue/95 flex flex-col items-center justify-center p-4 backdrop-blur-md overflow-y-auto"
            onClick={() => setSelectedItem(null)}
          >
            <button 
              className="absolute top-6 right-6 text-white hover:text-brand-yellow hover:-translate-y-1 transition-all bg-white/10 p-2 rounded-full z-10 border-2 border-brand-yellow"
              onClick={() => setSelectedItem(null)}
            >
              <X className="w-8 h-8" />
            </button>
            <div className="flex flex-col items-center max-w-5xl w-full my-auto" onClick={(e) => e.stopPropagation()}>
              <motion.img
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                src={selectedItem.fileData || selectedItem.link}
                alt={selectedItem.title}
                className="max-w-full max-h-[80vh] object-contain rounded-3xl shadow-[12px_12px_0px_0px_#FF9933] border-4 border-white bg-white"
              />
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="bg-white text-brand-blue border-4 border-brand-saffron rounded-3xl p-8 mt-8 max-w-3xl w-full mx-auto text-center shadow-[12px_12px_0px_0px_#FFFF00]"
              >
                <div className="flex items-center justify-center gap-4 mb-4">
                  <span className="text-4xl bg-brand-yellow p-3 rounded-2xl border-2 border-brand-blue shadow-[4px_4px_0px_0px_#003366]">{selectedItem.emoji}</span>
                  <h2 className="text-2xl md:text-3xl font-black uppercase tracking-wider">{selectedItem.title}</h2>
                </div>
                <p className="text-gray-700 text-lg font-bold leading-relaxed">{selectedItem.description}</p>
                <div className="mt-8 flex flex-col sm:flex-row items-center gap-6 justify-center w-full">
                  <div className="inline-block bg-brand-saffron text-white font-black px-6 py-4 border-2 border-brand-blue shadow-[4px_4px_0px_0px_#003366] rounded-xl tracking-widest text-lg">
                    {selectedItem.price}
                  </div>
                  <WhatsAppButton 
                    keyword={selectedItem.keyword}
                    className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white font-black uppercase px-8 py-4 shadow-[6px_6px_0px_0px_#128C7E] border-2 border-[#128C7E] rounded-xl transition-all hover:-translate-y-1 tracking-wider animate-btn-pulse"
                  >
                    <MessageCircle className="w-6 h-6" /> Order on WhatsApp
                  </WhatsAppButton>
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
