import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'motion/react';
import { Check, Edit, Save, X, PlusCircle, MessageCircle } from 'lucide-react';
import localforage from 'localforage';
import { PlanItem } from '../lib/db';
import { useAdmin } from '../context/AdminContext';
import { WhatsAppButton } from '../components/WhatsAppButton';

export default function Pricing() {
  const { isAdmin } = useAdmin();
  const [plans, setPlans] = useState<PlanItem[]>([]);
  const [editingPlan, setEditingPlan] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<PlanItem | null>(null);

  useEffect(() => {
    loadPlans();
  }, []);

  const loadPlans = async () => {
    const data = await localforage.getItem<PlanItem[]>('plans') || [];
    setPlans(data);
  };

  const handleEditClick = (plan: PlanItem) => {
    setEditingPlan(plan.id);
    setEditFormData({ ...plan, features: [...plan.features] });
  };

  const handleSave = async () => {
    if (!editFormData) return;
    const updated = plans.map(p => p.id === editFormData.id ? editFormData : p);
    await localforage.setItem('plans', updated);
    setPlans(updated);
    setEditingPlan(null);
    setEditFormData(null);
  };

  const updateFeatureArray = (index: number, val: string) => {
    if (!editFormData) return;
    const feats = [...editFormData.features];
    feats[index] = val;
    setEditFormData({ ...editFormData, features: feats });
  };

  const addFeature = () => {
    if (!editFormData) return;
    setEditFormData({ ...editFormData, features: [...editFormData.features, "🆕 New Feature"] });
  };

  return (
    <div className="py-12">
      <Helmet>
        <title>Pricing - Hidden Media Agency</title>
        <meta name="description" content="Simple and transparent pricing plans for all our digital services." />
      </Helmet>
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-black uppercase tracking-widest text-white mb-6">
          Simple Pricing
        </h1>
        <p className="text-lg text-white font-bold max-w-2xl mx-auto opacity-90">
          Choose the best plan for your needs. We offer unlimited benefits to accelerate your coaching center or business.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-8 justify-center items-stretch max-w-5xl mx-auto">
        {plans.map((plan, idx) => (
          <motion.div 
            key={plan.id}
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: idx * 0.1 }}
            className={`flex-1 ${plan.id === 'plan_yearly' ? 'bg-brand-yellow text-brand-blue border-brand-saffron shadow-[12px_12px_0px_0px_#FF9933]' : 'bg-white text-brand-blue border-brand-blue shadow-[12px_12px_0px_0px_#003366]'} rounded-3xl p-8 border-4 border hover:-translate-y-2 flex flex-col relative transition-all duration-300 animate-card-float`}
          >
            {isAdmin && editingPlan !== plan.id && (
              <button onClick={() => handleEditClick(plan)} className="absolute top-4 right-4 text-brand-blue bg-white p-2 rounded-full border-2 border-brand-blue hover:-translate-y-1 transition-all">
                <Edit className="w-5 h-5"/>
              </button>
            )}

            {editingPlan === plan.id && editFormData ? (
              // EDIT MODE
              <div className="flex flex-col gap-4 flex-1">
                <div className="flex justify-between items-center bg-gray-100 p-2 rounded-xl">
                  <span className="font-bold text-brand-blue px-2">Edit Mode</span>
                  <div className="flex gap-2">
                    <button onClick={handleSave} className="text-white bg-green-500 p-2 rounded hover:bg-green-600">
                      <Save className="w-5 h-5" />
                    </button>
                    <button onClick={() => setEditingPlan(null)} className="text-white bg-red-500 p-2 rounded hover:bg-red-600">
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                
                <label className="text-sm font-black uppercase text-brand-blue tracking-widest border-b-2 border-brand-blue pb-1">Emoji & Title</label>
                <div className="flex gap-2">
                  <input className="bg-white border-2 border-brand-blue p-2 w-16 text-center rounded-lg font-bold" value={editFormData.emoji} onChange={e => setEditFormData({...editFormData, emoji: e.target.value})} />
                  <input className="bg-white border-2 border-brand-blue p-2 flex-1 rounded-lg font-bold" value={editFormData.title} onChange={e => setEditFormData({...editFormData, title: e.target.value})} />
                </div>
                
                <label className="text-sm font-black uppercase text-brand-blue tracking-widest border-b-2 border-brand-blue pb-1">Subtitle</label>
                <input className="bg-white border-2 border-brand-blue p-2 rounded-lg w-full font-bold" value={editFormData.subtitle} onChange={e => setEditFormData({...editFormData, subtitle: e.target.value})} />
                
                <label className="text-sm font-black uppercase text-brand-blue tracking-widest border-b-2 border-brand-blue pb-1">Price & Duration</label>
                <div className="flex gap-2">
                  <input className="bg-white border-2 border-brand-blue p-2 flex-1 rounded-lg font-bold" value={editFormData.price} onChange={e => setEditFormData({...editFormData, price: e.target.value})} />
                  <input className="bg-white border-2 border-brand-blue p-2 flex-1 rounded-lg font-bold" value={editFormData.duration} onChange={e => setEditFormData({...editFormData, duration: e.target.value})} />
                </div>

                <label className="text-sm font-black uppercase text-brand-blue tracking-widest border-b-2 border-brand-blue pb-1">Code (Keyword)</label>
                <input className="bg-white border-2 border-brand-blue p-2 flex-1 rounded-lg font-bold" value={editFormData.keyword || ''} onChange={e => setEditFormData({...editFormData, keyword: e.target.value})} />

                <label className="text-sm font-black uppercase text-brand-blue tracking-widest border-b-2 border-brand-blue pb-1 mt-2">Features</label>
                {editFormData.features.map((feat, i) => (
                  <div key={i} className="flex gap-2 mb-2">
                    <input className="bg-white border-2 border-brand-blue p-2 flex-1 text-sm font-bold rounded-lg" value={feat} onChange={e => updateFeatureArray(i, e.target.value)} />
                    <button className="bg-red-500 text-white font-black px-3 rounded-lg border-2 border-brand-blue shadow-[2px_2px_0px_0px_#003366] hover:-translate-y-0.5" onClick={() => setEditFormData({...editFormData, features: editFormData.features.filter((_, fi) => fi !== i)})}>X</button>
                  </div>
                ))}
                <button onClick={addFeature} className="bg-brand-saffron text-white font-black border-2 border-brand-blue shadow-[2px_2px_0px_0px_#003366] p-3 rounded-lg flex items-center justify-center gap-2 hover:-translate-y-0.5"><PlusCircle className="w-5 h-5"/> Add Feature</button>
              </div>
            ) : (
              // VIEW MODE
              <>
                <div className="text-center mb-8 relative z-10">
                  <div className="text-5xl mb-4 p-4 inline-block bg-white rounded-2xl border-4 border-brand-blue shadow-[4px_4px_0px_0px_#003366]">{plan.emoji}</div>
                  <h2 className="text-3xl font-black uppercase tracking-widest mb-2">{plan.title}</h2>
                  <p className="font-bold text-sm tracking-widest uppercase opacity-80">{plan.subtitle}</p>
                </div>

                <div className={`rounded-2xl p-6 text-center mb-8 border-4 border-brand-blue shadow-[6px_6px_0px_0px_#003366] ${plan.id === 'plan_yearly' ? 'bg-white' : 'bg-brand-yellow'}`}>
                  <span className="text-5xl font-black">{plan.price}</span>
                  {plan.duration && <span className="text-xl font-bold ml-2">/{plan.duration}</span>}
                </div>

                <div className="space-y-4 mb-10 flex-1 relative z-10">
                  {plan.features.map((feat, i) => (
                     <div key={i} className="flex items-start gap-4">
                      <div className="bg-brand-saffron p-1.5 rounded-lg border-2 border-brand-blue shrink-0 shadow-[2px_2px_0px_0px_#003366]">
                        <Check className="w-5 h-5 text-white" />
                      </div>
                      <p className="font-bold leading-relaxed">{feat}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-auto relative z-10">
                  {plan.keyword && (
                    <div className="text-center text-sm font-black font-mono text-white bg-brand-blue px-3 py-2 mb-4 rounded-xl border-2 border-brand-saffron">
                      Code: <span className="text-brand-yellow font-black">{plan.keyword}</span>
                    </div>
                  )}
                  <WhatsAppButton 
                    keyword={plan.keyword}
                    className="flex justify-center items-center gap-2 w-full bg-[#25D366] text-white font-black uppercase py-4 rounded-xl border-4 border-[#128C7E] shadow-[6px_6px_0px_0px_#128C7E] transition-all hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_#128C7E] animate-btn-pulse"
                  >
                    <MessageCircle className="w-6 h-6" /> Subscribe Now
                  </WhatsAppButton>
                </div>
              </>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
}
